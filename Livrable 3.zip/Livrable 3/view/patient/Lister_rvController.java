/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.patient;

import entities.RendezVous;
import java.net.URL;
import java.util.List;
import java.util.Observable;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Lister_rvController implements Initializable {
    
    Service service = new Service();
    ObservableList<RendezVous> obvListRv;
    private RendezVous rvSelected;

    @FXML
    private TableView<RendezVous> tblvRv;
    @FXML
    private TableColumn<RendezVous, String> tblcRvDate;
    @FXML
    private TableColumn<RendezVous, String> tblcRvHeure;
    @FXML
    private TableColumn<RendezVous, String> tblcRvType;
    @FXML
    private TableColumn<RendezVous, String> tblcRvEtat;
    @FXML
    private Button idButtonDeleteRv;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTableView();
        idButtonDeleteRv.setVisible(false);
    }   
    
    public void loadTableView(){
    int id = 0;
    id = ConnexionController.getCtrl().getUser().getId();
    List<RendezVous> listeRv = service.searchRvById(id);
    obvListRv = FXCollections.observableArrayList(listeRv);
    tblcRvDate.setCellValueFactory(new PropertyValueFactory<>("date"));
    tblcRvHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
    tblcRvType.setCellValueFactory(new PropertyValueFactory<>("type"));
    tblcRvEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
    tblvRv.setItems(obvListRv);
}

    @FXML
    private void handleSelectRv(MouseEvent event) {
        rvSelected = tblvRv.getSelectionModel().getSelectedItem();
        idButtonDeleteRv.setVisible(true);
    }

    @FXML
    private void handleDeleteRv(ActionEvent event) {
        //supprimer le rendez-vous : je reviens sur ca 
    }
    
    
}
