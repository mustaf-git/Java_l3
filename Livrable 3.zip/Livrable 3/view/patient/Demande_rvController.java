/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.patient;

import entities.Patient;
import entities.RendezVous;
import entities.User;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Demande_rvController implements Initializable {
    
    private Service service = new Service();
    private static Demande_rvController ctrl;
    private String typeRv;
    private String choixPrestation;


    @FXML
    private TextField txtfDate;
    @FXML
    private TextField txtfHeure;
    @FXML
    private ComboBox<String> cboTypeRv;
    @FXML
    private ComboBox<String> cboChoixPrestation;
    @FXML
    private Button txtfConfirmerDemandeRv;
    @FXML
    private Text txtError;
    
    @FXML
    private Text txtErrorPrestation;


    
    
    


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        cboTypeRv.getItems().add("consultation");
        cboTypeRv.getItems().add("prestation");
        cboTypeRv.getSelectionModel().selectFirst();
        typeRv = cboTypeRv.getSelectionModel().getSelectedItem();
        
        
        cboChoixPrestation.setDisable(true);
        
        cboChoixPrestation.getItems().add("Radio");
        cboChoixPrestation.getItems().add("analyse");
        cboChoixPrestation.getItems().add("scanner");
        cboChoixPrestation.getSelectionModel().selectFirst();
        choixPrestation = cboChoixPrestation.getSelectionModel().getSelectedItem();
        
        txtfConfirmerDemandeRv.setVisible(false);
        
        txtError.setVisible(false);
        txtErrorPrestation.setVisible(false);
        
        ctrl = this;    
    }


    @FXML
    private void handleChangerTypeRv(ActionEvent event) {
        typeRv = cboTypeRv.getSelectionModel().getSelectedItem();
    }

    @FXML
    private void handleChangerTypePrestation(ActionEvent event) {
        choixPrestation = cboChoixPrestation.getSelectionModel().getSelectedItem();
    }
    
    
    @FXML
    private RendezVous handleDemanderRv(ActionEvent event) {
        
        Patient patient = null;
        RendezVous rv = null ;
        
        String date = txtfDate.getText().trim();
        String heure = txtfHeure.getText().trim();
        String typeRv = Demande_rvController.getCtrl().getTypeRv();
        String libellePrestation = Demande_rvController.getCtrl().getChoixPrestation();
        //System.out.println(type);
        //System.out.println(libellePrestation);
        String etat = "En attente";
        
        int idPatient = ConnexionController.getCtrl().getUser().getId();
        patient = service.searchPatientById(idPatient);
        if(date.isEmpty() || heure.isEmpty()){
            txtError.setText("tous les champs sont obligatoires");
            txtError.setVisible(true);
        }else if(typeRv.compareTo("prestation")==0){
            cboTypeRv.setDisable(true);
            cboChoixPrestation.setDisable(false);
            txtfConfirmerDemandeRv.setVisible(true);
            //rv = new RendezVous(date, heure, typeRv, etat, libellePrestation, patient);
        }else if(typeRv.compareTo("consultation")==0){
            cboTypeRv.setDisable(true);
            txtfConfirmerDemandeRv.setVisible(true);
            rv = new RendezVous(date, heure, typeRv, etat, patient);
        }
     
        return rv;
    }

    @FXML
    private void handleConfirmerDemandeRv(ActionEvent event) {
        
        RendezVous rv = handleDemanderRv(event);
        int idRv = service.addRv(rv);
        rv.setId(idRv);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Rensez-Vous");
        alert.setContentText("demande de rendez-vous effectuée avec succès");
        alert.show();
        handleClearDemandeRv(event);
    }
    
    
    @FXML
    private void handleClearDemandeRv(ActionEvent event) {
        txtfDate.clear();
        txtfHeure.clear();
        cboChoixPrestation.setDisable(true);
        cboTypeRv.setDisable(false);
        txtfConfirmerDemandeRv.setVisible(false);
    }
    
    
    
    public static Demande_rvController getCtrl() {
        return ctrl;
    }
    
    public String getTypeRv() {
        return typeRv;
    }

    public String getChoixPrestation() {
        return choixPrestation;
    }


    
    
    
    
}
