/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.patient;

import entities.Consultation;
import entities.RendezVous;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Lister_consultationController implements Initializable {

    Service service = new Service();
    ObservableList<RendezVous> obvListRv;
    
    @FXML
    private TableView<Consultation> tblvCons;
    @FXML
    private TableColumn<Consultation, String> tblcConDate;
    @FXML
    private TableColumn<Consultation, String> tblcConsHeure;
    @FXML
    private TableColumn<Consultation, String> tblcMedCons;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    

}

    

