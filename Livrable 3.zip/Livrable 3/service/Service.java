/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import dao.PatientDao;
import dao.RendezVousDao;
import dao.UserDao;
import entities.Consultation;
import entities.Patient;
import entities.Prestation;
import entities.RendezVous;
import entities.User;
import java.util.List;

/**
 *
 * @author DELL
 */
public class Service implements IService{
    // dependances
    UserDao userDao = new UserDao();
    PatientDao patientDao = new PatientDao();
    RendezVousDao rendezVousDao = new RendezVousDao();
    
    //
    
    
    // Se connecter
    @Override
    public User login(String login, String password) {
        return userDao.findUserLoginAndPassword(login, password);
    }
    // tester l'unicité du login
    @Override
    public User loginExist(String login) {
        return userDao.findUserByLogin(login);
    }
    // créer compte patient : inscription patient
    @Override
    public int addPatient(Patient patient) {
        return patientDao.insert(patient);
    }
    public Patient searchPatientById(int id){
        return patientDao.selectById(id);
    }
    // créer un rendez Vous
    @Override
    public int addRv(RendezVous rv) {
        return rendezVousDao.insert(rv);
    }
    // afficher les rendez vous
    @Override
    public List<RendezVous> searchRvById(int id) {
        return rendezVousDao.selectAllRvById(id);
    }


    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @Override
    public List<Prestation> saerchPrestationById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> searchConsultationById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int removeRv(RendezVous rv) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int validateRv(RendezVous rv) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<RendezVous> serachDossierMedicalByIdPatient(int idPatient) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultation> searchConsultationByDate() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void showDetailsConsultation(Consultation consultation) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int removeConsultation(Consultation consultation) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Prestation> searchPrestationByDate() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void showDetailsPrestation(Prestation prestation) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int removePrestation(Consultation consultation) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
