/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import javafx.scene.control.ComboBox;

/**
 *
 * @author DELL
 */
public class ViewService {
    
    
    public static void loadComboBoxHeure(ComboBox<String> cboHeure){
        cboHeure.getItems().add("08:00");
        cboHeure.getItems().add("09:00");
        cboHeure.getItems().add("10:00");
        cboHeure.getItems().add("11:00");
        cboHeure.getItems().add("12:00");
        cboHeure.getItems().add("15:00");
        cboHeure.getItems().add("16:00");
        cboHeure.getItems().add("17:00");
        cboHeure.getItems().add("18:00");
        cboHeure.getSelectionModel().selectFirst();
    } 
}
