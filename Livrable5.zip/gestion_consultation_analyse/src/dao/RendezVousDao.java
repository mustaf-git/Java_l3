/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.Patient;
import entities.RendezVous;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DELL
 */
public class RendezVousDao implements IDao<RendezVous>{
// dependences
    DataBase database = new DataBase();
//
    
    
// requette sql pour traitement des rendez vous
    // inserer rv
    private final String SQL_INSERT = "INSERT INTO `rendez_vous` (`date`,"
    + " `heure`, `type`, `etat`, `id_patient`) "
    + " VALUES (?, ?, ?, ?, ?)";
    // Lister tous les rvs
    private final String SQL_ALL_RV = "SELECT * FROM `rendez_vous` WHERE `etat` = ?";
    // lister les rvs d'un patient
    private final String SQL_ALL_RV_BY_ID_PATIENT = "SELECT * FROM `rendez_vous` WHERE `id_patient` = ? and `etat` = ?";
    // supprimer un rv
    private final String SQL_DELETE = " DELETE FROM `rendez_vous` WHERE `id` = ? ";
    // valider un rv
    private final String SQL_VALIDATE_RV = "UPDATE `rendez_vous` SET `etat`= ?,`id_medecin`= ? WHERE id=?";
    
    // lister les rvs => dossier medical
// *******
    
    // inserer un rv : créer un rendez vous : planifier rv
    @Override
    public int insert(RendezVous rv) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    // lister tous les rendez vous 
    public List<RendezVous> selectAllRv(){
        List<RendezVous> rvs = new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_ALL_RV);
        try {
            database.getPs().setString(1, "en attente");
            ResultSet rs = database.executeSelect(SQL_ALL_RV);
            while(rs.next()){
                try {
                    int id = rs.getInt("id");
                    Date date = rs.getDate("date");
                    String heure = rs.getString("heure");
                    String etat = rs.getString("etat");
                    String type = rs.getString("type");
                    int idPatient = rs.getInt("id_patient");
                    PatientDao patientDao = new PatientDao();
                    Patient patient = patientDao.selectById(idPatient);
                    RendezVous rv = new RendezVous(id, date, heure, type, etat, patient);
                    rvs.add(rv);   
                } catch (SQLException ex) {
                    Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }

        database.closeConnexion();
        return rvs;
    }
    
    // lister tous les rendez vous d'un patient 
    public List<RendezVous> selectAllRvByIdPatient(int id){
        List<RendezVous> rvs = new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_ALL_RV_BY_ID_PATIENT);
        try {
            database.getPs().setInt(1, id);
            database.getPs().setString(2, "en attente");
            ResultSet rs = database.executeSelect(SQL_ALL_RV_BY_ID_PATIENT);
                        while(rs.next()){
                try {
                    //Mapping relation vers objet
                    RendezVous rv = new RendezVous(rs.getDate("date"), rs.getString("heure"),
                            rs.getString("type"), rs.getString("etat"));
                    rvs.add(rv);
                } catch (SQLException ex) {
                    Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
        database.closeConnexion();
        return rvs;
    }
   
    // supprimer un rendez vous
    @Override
    public int delete(int id) {
        int idRvSup=0;
        database.openConnexion();
        database.initPrepareStatement(SQL_DELETE);
        try {
            database.getPs().setInt(1,id);
            idRvSup = database.executeUpdate(SQL_DELETE);
            System.out.println(idRvSup);
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        database.closeConnexion();
        return idRvSup;
    }
    
    // valider un rv
    public int validateRv(int idMedecin,int idRv){
        int nbLigneModif = 0;
        database.openConnexion();
        database.initPrepareStatement(SQL_VALIDATE_RV);
        try {
            database.getPs().setString(1, "validé");
            database.getPs().setInt(2, idMedecin);
            database.getPs().setInt(3, idRv);
            nbLigneModif = database.executeUpdate(SQL_VALIDATE_RV);
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return nbLigneModif;
    }
    
    
    
    // lister tous les rendez vous d'un patient 
    public List<RendezVous> selectDossMedByPatient(int id){
        List<RendezVous> rvs = new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_ALL_RV_BY_ID_PATIENT);
        try {
            database.getPs().setInt(1, id);
            database.getPs().setString(2, "validé");
            ResultSet rs = database.executeSelect(SQL_ALL_RV_BY_ID_PATIENT);
                        while(rs.next()){
                try {
                    //Mapping relation vers objet
                    RendezVous rv = new RendezVous(rs.getDate("date"), rs.getString("heure"),
                            rs.getString("type"), rs.getString("etat"));
                    rvs.add(rv);
                } catch (SQLException ex) {
                    Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(RendezVousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        database.closeConnexion();
        return rvs;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
  
    
  
    
        
    
    
    
    
    
    
    
    @Override
    public int update(RendezVous ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



    @Override
    public List<RendezVous> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public RendezVous selectById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
    
    
    
    
    
}
