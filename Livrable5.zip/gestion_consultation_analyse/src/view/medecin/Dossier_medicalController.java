/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.medecin;


import entities.Patient;
import entities.RendezVous;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import service.Service;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Dossier_medicalController implements Initializable {

    Service service = new Service();
    ObservableList<RendezVous> obvListRv;
    

    @FXML
    private TableView<RendezVous> tblvDoss;
    @FXML
    private TableColumn<RendezVous, Date> tblcDateRvDoss;
    @FXML
    private TableColumn<RendezVous, String> tblcHeureRvDoss;
    @FXML
    private TableColumn<RendezVous, String> tblcTypeRvDoss;
    @FXML
    private TableColumn<RendezVous, String> tblcLibelleRvDoss;
    @FXML
    private TextField txtfPrenomPatient;
    @FXML
    private TextField txtfAntMedPatient;
    @FXML
    private TextField txtfNomPatient;
    @FXML
    private TextField txtfCodePatient;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Patient patient = HomeController.getCtrlMed().getPatient();
        txtfPrenomPatient.setText(patient.getPrenom());
        txtfNomPatient.setText(patient.getNom());
        txtfCodePatient.setText(patient.getCode());
        txtfAntMedPatient.setText(patient.getAntecedantMedicaux());
        
       
        int idPatient = 0;
        idPatient = patient.getId();
        List<RendezVous> listeRv = service.searchDossMedByPatient(idPatient);
        obvListRv = FXCollections.observableArrayList(listeRv);
        tblcDateRvDoss.setCellValueFactory(new PropertyValueFactory<>("date"));
        tblcHeureRvDoss.setCellValueFactory(new PropertyValueFactory<>("heure"));
        tblcTypeRvDoss.setCellValueFactory(new PropertyValueFactory<>("type"));
        tblvDoss.setItems(obvListRv);

    
        

    }    
    
        
    
    

   
        
        
    


    
}
