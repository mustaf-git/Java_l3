/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.medecin;
import entities.Consultation;
import entities.Patient;
import entities.Prestation;
import entities.RendezVous;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class HomeController implements Initializable {

    private static HomeController ctrlMed;
    private Patient patient;
    private Service service = new Service();

    public static HomeController getCtrlMed() {
        return ctrlMed;
    }
    public Patient getPatient(){
        return patient;
    }
    @FXML
    private AnchorPane anchorContent;
    @FXML
    private Text txtLoginConnecte;
    @FXML
    private TextField txtfLoginForDossierMedical;


    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtLoginConnecte.setText("Email : " + ConnexionController.getCtrl().getUser().getLogin());
        try {  
            loadView("v_lister_consultation");
            /*initialiser le controller dans la methode imiatialse*/
            ctrlMed = this;
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }  
    
    
    
        private void loadView(String view) throws IOException{
        AnchorPane root;
        root = FXMLLoader.load(getClass().getResource("/view/medecin/"+view+".fxml"));
        anchorContent.getChildren().clear();
        anchorContent.getChildren().add(root);
    }

    @FXML
    private void handleAddRv(ActionEvent event) throws IOException {
        loadView("v_demande_rv");
    }

    @FXML
    private void handleShowRv(ActionEvent event) throws IOException {
        loadView("v_lister_rv");
    }

    @FXML
    private void handleShowConsultation(ActionEvent event) throws IOException {
        loadView("v_lister_consultation");
    }

    @FXML
    private void handleSearchDossierMedical(MouseEvent event) throws IOException {
        
        String loginPatient = txtfLoginForDossierMedical.getText().trim();
        patient = service.searchPatientByLogin(loginPatient);
        if(patient != null){
            loadView("v_dossier_medical");
            
        }else{
            System.out.println("Ce patient n'existe pas ");
        }

        
    
}
}