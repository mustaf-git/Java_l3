/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.medecin;

import entities.Consultation;
import entities.Patient;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Lister_consultationController implements Initializable {

    Service service = new Service();
    ObservableList<Consultation> obvListCons;
    Consultation consultationSelected;
    
    @FXML
    private TableView<Consultation> tblvCons;
    @FXML
    private TableColumn<Consultation, Date> tblcConDate;
    @FXML
    private TableColumn<Consultation, String> tblcConsHeure;
    
    @FXML
    private TableColumn<Consultation, Patient> tblcConsPatient;
    
    @FXML
    private Button idButtonAnnulerCons;
    @FXML
    private DatePicker dpDateDeb;
    @FXML
    private DatePicker dpDateFin;
    
    java.sql.Date dateDeb;
    java.sql.Date dateFin;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       loadTableView();
        idButtonAnnulerCons.setVisible(false);
       


    }    
    
    public void loadTableView(){
    int id = 0;
    id = ConnexionController.getCtrl().getUser().getId();
    List<Consultation> listeCons = service.searchAllConsultationByIdMedecin(id);
    obvListCons = FXCollections.observableArrayList(listeCons);
    tblcConDate.setCellValueFactory(new PropertyValueFactory<>("date"));
    tblcConsHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
    tblcConsPatient.setCellValueFactory(new PropertyValueFactory<>("patient"));

    tblvCons.setItems(obvListCons);
}
    
    
    @FXML
    private void handleSelectCons(MouseEvent event) {
        consultationSelected = tblvCons.getSelectionModel().getSelectedItem();
        if(consultationSelected != null){
            idButtonAnnulerCons.setVisible(true);
            
            
        }
    }

    @FXML
    private void handleAnnulerCons(ActionEvent event) {
        
                consultationSelected = tblvCons.getSelectionModel().getSelectedItem();
        if(consultationSelected != null){
            int idCons = consultationSelected.getId();
                Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Suppression d'une consultation");
                alert.setContentText("Voulez vous annuler cette prestation ?");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK){
                service.removeCons(idCons);
                loadTableView();
                alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Consultation annulée avec succès");
                alert.show();
                loadTableView();
        }
            
        }else{
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Merci de selectionner une consultation");
                alert.show();
        }
        
        
    }

    @FXML
    private void handleFiltrerCons(ActionEvent event) {
        
        dateDeb = java.sql.Date.valueOf(dpDateDeb.getValue());
        dateFin = java.sql.Date.valueOf(dpDateFin.getValue());
        
        
        
        int idMed = 0;
        idMed = ConnexionController.getCtrl().getUser().getId();
        List<Consultation> listeCons = service.searchAllConsultationByIdMedecinAndDate(idMed,dateDeb, dateFin);
        obvListCons = FXCollections.observableArrayList(listeCons);
        tblcConDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tblcConsHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
        tblcConsPatient.setCellValueFactory(new PropertyValueFactory<>("patient"));

        tblvCons.setItems(obvListCons);
        
        
    }


    
}
