/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.medecin;

import view.secretaire.*;
import entities.Medecin;
import view.patient.*;
import entities.RendezVous;
import java.net.URL;
import java.util.Date;
import java.util.List;
import java.util.Observable;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import service.Service;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Lister_rvController implements Initializable {
    
    // dependences
    
    Service service = new Service();
    
    //
    
    // créer un observableList : sujet d'observation pour la liste:  => actualiser la liste automatiquement s'il s'actualise
    ObservableList<RendezVous> obvListRv;
    ObservableList<Medecin> obvListMedecin;
    
    
    // recupérer le rendez-vous electionné grace au clic de la souris sur un élément de la liste : du tableau : tableview
    private RendezVous rvSelected = null;

    
    
    // variable fxml
    @FXML
    private TableView<RendezVous> tblvRv;
    @FXML
    private TableColumn<RendezVous, Date> tblcRvDate;
    @FXML
    private TableColumn<RendezVous, String> tblcRvHeure;
    @FXML
    private TableColumn<RendezVous, String> tblcRvType;
    @FXML
    private TableColumn<RendezVous, String> tblcRvEtat;
    @FXML
    private TableColumn<RendezVous, String> tblcNomPatient;
    private Button idButtonAnnulerRv;
    private Button idButtonValiderRv;
    private ComboBox<Medecin> cboChoixMedecin;
    private Button idButtonEnregistrer;
    private Text txtError;
    
    

    /**
     * Initializes the controller class.
     */
    
    //au chargement de la page 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTableView();


    }   
    
    //
    public void loadTableView(){
    List<RendezVous> listeRv = service.searchAllRv();
    // transformer la liste de rvs récupéré en une observableList 
    obvListRv = FXCollections.observableArrayList(listeRv);
    // Construire les colones du table( table view => vu fxml ) à partir des elements de l'objet de ce type de liste
    tblcRvDate.setCellValueFactory(new PropertyValueFactory<>("date"));
    tblcRvHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
    tblcRvType.setCellValueFactory(new PropertyValueFactory<>("type"));
    tblcRvEtat.setCellValueFactory(new PropertyValueFactory<>("etat"));
    tblcNomPatient.setCellValueFactory(new PropertyValueFactory<>("patient"));
    //ajouter chaque ligne de cette observableList dans le tableau ( table view : vu fxml )
    tblvRv.setItems(obvListRv);
}





    


    
}
