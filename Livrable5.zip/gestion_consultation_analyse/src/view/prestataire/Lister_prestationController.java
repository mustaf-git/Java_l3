/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view.prestataire;

import view.patient.*;
import entities.Prestation;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import service.Service;
import java.util.Date;
import view.ConnexionController;

/**
 * FXML Controller class
 *
 * @author DELL
 */
public class Lister_prestationController implements Initializable {

    Service service = new Service();
    Prestation prestationSelected;
    ObservableList<Prestation> obvListPres;
    
    @FXML
    private TableView<Prestation> tblvPres;
    @FXML
    private TableColumn<Prestation, Integer> tblcIdPres;
    @FXML
    private TableColumn<Prestation, Date> tblcPresDate;
    @FXML
    private TableColumn<Prestation, String> tblcPresHeure;
    @FXML
    private TableColumn<Prestation, String> tblcLibPres;
    @FXML
    private Button idButtonAnnuler;
    
    @FXML
    private DatePicker dpDateDeb;
    @FXML
    private DatePicker dpDateFin;
    java.sql.Date dateDeb;
    java.sql.Date dateFin;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
@Override
    public void initialize(URL url, ResourceBundle rb) {
       loadTableView();
        idButtonAnnuler.setVisible(false);
    }    
    
    public void loadTableView(){
    //int id = 0;
    //id = ConnexionController.getCtrl().getUser().getId();
    List<Prestation> listePres = service.searchAllPrestation();
    obvListPres = FXCollections.observableArrayList(listePres);
    tblcIdPres.setCellValueFactory(new PropertyValueFactory<>("id"));
    tblcPresDate.setCellValueFactory(new PropertyValueFactory<>("date"));
    tblcPresHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
    tblcLibPres.setCellValueFactory(new PropertyValueFactory<>("libellePrestation"));
    tblvPres.setItems(obvListPres);
}



    @FXML
    private void handleSelectPrestation(MouseEvent event) {
        prestationSelected = tblvPres.getSelectionModel().getSelectedItem();
        if(prestationSelected != null){
            idButtonAnnuler.setVisible(true);
        }
    }
    
    @FXML
    private void handleAnulerPrestation(ActionEvent event) {
        prestationSelected = tblvPres.getSelectionModel().getSelectedItem();
        if(prestationSelected != null){
            int idPres = prestationSelected.getId();
                Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Suppression d'une prestation");
                alert.setContentText("Voulez vous annuler cette prestation ?");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.get() == ButtonType.OK){
                service.removePres(idPres);
                loadTableView();
                alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Prestation annulée avec succès");
                alert.show();
                loadTableView();
        }
            
        }else{
                Alert alert=new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Merci de selectionner une prestation");
                alert.show();
        }
        
        
    }

    @FXML
    private void handleFiltrerPres(ActionEvent event) {
        
        dateDeb = java.sql.Date.valueOf(dpDateDeb.getValue());
        dateFin = java.sql.Date.valueOf(dpDateFin.getValue());
        
        List<Prestation> listePres = service.searchAllPrestationByDate(dateDeb, dateFin);
        obvListPres = FXCollections.observableArrayList(listePres);
        tblcIdPres.setCellValueFactory(new PropertyValueFactory<>("id"));
        tblcPresDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        tblcPresHeure.setCellValueFactory(new PropertyValueFactory<>("heure"));
        tblcLibPres.setCellValueFactory(new PropertyValueFactory<>("libellePrestation"));
        tblvPres.setItems(obvListPres);

    }


    
}
